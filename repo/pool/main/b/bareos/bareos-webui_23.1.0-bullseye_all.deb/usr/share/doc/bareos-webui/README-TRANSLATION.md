
TRANSLATION
===========

Please see: https://docs.bareos.org/DeveloperGuide/Webui.html#translation
